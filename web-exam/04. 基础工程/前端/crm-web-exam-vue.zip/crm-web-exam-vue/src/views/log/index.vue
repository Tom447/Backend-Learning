<template>
  <div class="app-container">
    <h1>题目8: 根据页面原型，完成日志查询前端页面的制作。</h1>
  </div>
</template>

<script>

</script>

<style>

</style>
