<template>
  <div class="dashboard-container">
     <img src="@/assets/crm.png" width="100%" >
  </div>
</template>

<script>
export default {
  name: 'Dashboard',
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 0px;
  }
}
</style>
